# [Friends_Scripts](https://doingharder.github.io/Friends_Scripts/1.html)
# [The Big Bang Theory_Scripts](https://doingharder.github.io/TBBT_Scripts/1.html)
#    Annotated by [ncp](http://soncp.com/)
